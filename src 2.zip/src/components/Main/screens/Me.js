import React, { Component } from 'react';
import { Alert, ScrollView, View ,Image, SafeAreaView, StyleSheet, Text, TouchableOpacity} from 'react-native';
import { Tile, List, ListItem, Button} from 'react-native-elements';
import { me } from '../config/data';
import firebase from 'firebase';

class Me extends Component {
  componentWillMount(){
    const firebaseConfig = {
        apiKey: 'AIzaSyD86ea0QlrVd2MSr3Z0eHJBKgIcKtnMi5A',
        authDomain: 'scut-project.firebaseapp.com',
        databaseURL: "https://scut-project.firebaseio.com",
        projectId: "scut-project",
        storageBucket: "scut-project.appspot.com",
        messagingSenderId: "527713997669"
    };
    if (!firebase.apps.length) {
        firebase.initializeApp(firebaseConfig);
    }
    console.log(firebase);
  }
  
  handleSettingsPress = () => {
    this.props.navigation.navigate('Settings');
  };

  render() {
    var user = firebase.auth().currentUser;
    return (
      <View>
        <SafeAreaView />

        <View style={styles.profile}>
          <Image
              style={{justifyContent:'center'}}
              source = {require('../../../images/baseline_account_circle_black_48pt_2x.png')}
          />
          <Text>{user.displayName}</Text>
        </View>

        <Button
          title="Settings"
          buttonStyle={{ marginTop: 20 }}
          onPress={this.handleSettingsPress}
        />

        <List>
          <ListItem
            title="Full Name"
            rightTitle={user.displayName}
            hideChevron
          />
          <ListItem
            title="Email"
            rightTitle={user.email}
            hideChevron
          />
        </List>

        <List>
          <TouchableOpacity onPress={()=>{Alert.alert(`User ID`,user.uid)}}>
            <ListItem
              title="UserId"
              rightTitle={user.uid}
            />
          </TouchableOpacity>
        </List>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  profileImage: {
    marginBottom: 20,

  },
  profile: {
    flexGrow: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  
});
Me.defaultProps = { ...me };

export default Me;
