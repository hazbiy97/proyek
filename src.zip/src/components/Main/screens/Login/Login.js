/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  KeyboardAvoidingView,
  StatusBar,
  YellowBox,
} from 'react-native';
import LoginForm from './LoginForm.js';
//ignore bugs
YellowBox.ignoreWarnings(['Module RCTImageLoader requires',]);

export default class Login extends Component {
  render() {
    var { navigate } = this.props.navigation;
    return (
      <KeyboardAvoidingView behavior="padding" style={styles.container}>
        <StatusBar
          barStyle="light-content"
        />
        <View style={styles.logoContainer}>
          <Image
            style = {styles.logo}
            source = {require('../../../../images/loginImage.jpg')}
          />
          <Text style={styles.sloganText}>Steven Production @2018</Text>
        </View>
        <View style= {styles.formContainer}>
          <LoginForm navigation={this.props.navigation}/>
        </View>
      </KeyboardAvoidingView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,1)'
  },
  logoContainer: {
    flexGrow: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  logo: {
    width : 200,
    height : 50
  },
  sloganText:{
    //color : '#3498db',
    marginTop: 10,
    width: 160,
    textAlign: 'center',
    opacity: 0.9
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    //color: '#333333',
    marginBottom: 5,
  }
});
