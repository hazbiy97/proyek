import React, { Component } from 'react';
import {
  Alert,
  StyleSheet,
  TextInput,
  View,
  Text,
  TouchableOpacity,
  StatusBar,
  ActivityIndicator
} from 'react-native';
import * as firebase from 'firebase';

export default class LoginForm extends Component {
  componentWillMount(){
    const firebaseConfig = {
      apiKey: 'AIzaSyD86ea0QlrVd2MSr3Z0eHJBKgIcKtnMi5A',
      authDomain: 'scut-project.firebaseapp.com',
      databaseURL: "https://scut-project.firebaseio.com",
      projectId: "scut-project",
      storageBucket: "scut-project.appspot.com",
      messagingSenderId: "527713997669"
    };
    if (!firebase.apps.length) {
      firebase.initializeApp(firebaseConfig);
    }
    console.log(firebase);
  }

  state = {
    email: '',
    password: '',
    authenticating: false,
    user: null
  }

  onPressSignIn(){
    this.setState({
      authenticating : true
    });
    const { email, password } = this.state
    firebase.auth().signInWithEmailAndPassword(email, password)
    .then((user) => {
      this.setState({authenticating:false});
      // If you need to do anything with the user, do it here
      // The user will be logged in automatically by the 
      // `onAuthStateChanged` listener we set up in App.js earlier
    })
    .catch((error) => {
      const { code, message } = error;
      // For details of error codes, see the docs
      // The message contains the default Firebase string
      // representation of the error
      this.setState({authenticating:false});
      errorCode = error.code;
      //errorMessage = error.message;
      //alert(errorCode);
      switch (errorCode){
        case 'auth/weak-password' :
          console.log("Network connection error");
          alert("Network connection error");
          break;
        case 'auth/invalid-email':
          console.log("Invalid email");
          alert("Invalid email");
          break;
        case 'auth/user-not-found':
          console.log("User not found");
          alert("User not found");
          break;
        case 'auth/network-request-failed':
          console.log("Network connection error");
          alert("Network connection error");
          break;
        case 'auth/wrong-password':
          console.log("Wrong password");
          alert("Wrong password");
          break;
        default:
          console.log("Error occured");
          alert("Error occured");
          break;
      }
    });
  }
  
  loginButton() {
    if (this.state.authenticating){
      return (
        <TouchableOpacity style={styles.buttonContainer} disabled={true}>
          <ActivityIndicator size='small' style={{height: 25}} />
        </TouchableOpacity>
      );
    }else{
      return(
        <TouchableOpacity style={styles.buttonContainer} onPress={() => this.onPressSignIn()}>
          <Text style={styles.buttonText}>Log In</Text>
        </TouchableOpacity>
      );
    }
  }

  renderCurrentState(){
    return (
      <View>
      <View style={styles.container}>
        <TextInput 
          borderColor='rgba(220,220,220,1)'
          borderWidth= {1}
          placeholder="Email"
          placeholderTextColor = "gray"
          returnKeyType = "next"
          keyboardType="email-address"
          autoCapitalize= "none"
          autoCorrect={false}
          onChangeText= {email => this.setState({email})}
          value = {this.state.email}
          onSubmitEditing = {() => this.passwordInput.focus()}
          style = {styles.input}
        />
        <TextInput 
          borderColor='rgba(220,220,220,1)'
          borderWidth= {1}
          placeholder="Password"
          placeholderTextColor = "gray"
          placholderAlign = "center"
          returnKeyType = "go"
          secureTextEntry
          onChangeText={password => this.setState({ password })}
          value={this.state.password}
          style = {styles.input}
          ref= {(input) => this.passwordInput = input}  
        />
        {this.loginButton()}
      </View> 
      <View style={styles.descContainer}>
        <Text style={styles.descText}>Don't have an account? <Text onPress={() => this.props.navigation.navigate('SignUp')} style={{color:'black'}} >Sign Up.</Text></Text>
      </View>
      </View>
    )
  }

  /**
   * When the App component mounts, we listen for any authentication
   * state changes in Firebase.
   * Once subscribed, the 'user' parameter will either be null 
   * (logged out) or an Object (logged in)
   */
  componentDidMount() {
    this.authSubscription = firebase.auth().onAuthStateChanged((user) => {
      this.setState({
        authenticating: false,
        user
      });
      firebase.auth().signOut();
      user ? this.props.navigation.navigate('Tabs') : null;
    });
  }
  /**
   * Don't forget to stop listening for authentication state changes
   * when the component unmounts.
   */
  componentWillUnmount() {
    this.authSubscription();
  }

  render(){
    return (
      this.renderCurrentState()
    )
  }
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 20,
  },
  input: {
    height: 40,
    backgroundColor: 'rgba(245,245,245,1)',
    marginBottom: 15,
    paddingHorizontal : 10
  },
  loading: {
    height: 175
  },
  descContainer:{
    height : 40,
    paddingVertical : 10,
    borderTopColor: 'rgba(220,220,220,1)',
    borderTopWidth: 1.5,
    marginTop :10,
  },
  descText:{
    color:'gray',
    fontWeight: '400',
    textAlign: 'center',
    fontSize: 12,
  },
  buttonContainer: {
    borderColor:'rgba(220,220,220,1)',
    borderWidth: 1,
  	paddingVertical: 10
  },
  buttonText:{
  	textAlign : 'center',
    height: 20,
  	fontWeight: '700'
  }
});
