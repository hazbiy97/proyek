/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  KeyboardAvoidingView,
  StatusBar,
  SafeAreaView,
  TouchableOpacity
} from 'react-native';
import { Button } from 'react-native-elements';
import SignUpForm from './SignUpForm';
//const util = require('util');

export default class SignUp extends Component {
  render() {
    var { navigate } = this.props.navigation;
    return (
      <KeyboardAvoidingView behavior="padding" style={styles.container}>
        <SafeAreaView/>
        <SignUpForm navigation= {this.props.navigation}/>
      </KeyboardAvoidingView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  logoContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  logo: {
    width : 200,
    height : 50
  },
  slogan :{
    color : '#FFF',
    marginTop: 10,
    width: 160,
    textAlign: 'center',
    opacity: 0.9
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
  closeButton: {
    marginLeft: 5,
    marginTop: 5,
  }
});
