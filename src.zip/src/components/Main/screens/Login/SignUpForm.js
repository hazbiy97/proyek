import React, { Component } from 'react';
import {
  Alert,
  StyleSheet,
  TextInput,
  View,
  Text,
  TouchableOpacity,
  StatusBar,
  ActivityIndicator
} from 'react-native';
import * as firebase from 'firebase';

export default class SignUpForm extends Component {
  componentWillMount(){
    const firebaseConfig = {
      apiKey: 'AIzaSyD86ea0QlrVd2MSr3Z0eHJBKgIcKtnMi5A',
      authDomain: 'scut-project.firebaseapp.com',
      databaseURL: "https://scut-project.firebaseio.com",
      projectId: "scut-project",
      storageBucket: "scut-project.appspot.com",
      messagingSenderId: "527713997669"
    };
    if (!firebase.apps.length) {
        firebase.initializeApp(firebaseConfig);
    }
  }

  state = {
    email: '',
    password: '',
    retypePassword: '',
    authenticating: false
  }

  onPressSignUp(){
    this.setState({
      authenticating : true
    });
    const { email, password,retypePassword } = this.state;
    if(password === retypePassword){
      firebase
      .auth()
      .createUserWithEmailAndPassword(email, password)
      .then(
        () => this.props.navigation.navigate('Main')
      )
      .catch((error) => {
        const { code, message } = error;
        // For details of error codes, see the docs
        // The message contains the default Firebase string
        // representation of the error
        this.setState({authenticating:false});
        errorCode = error.code;
        //errorMessage = error.message;
        //alert(errorCode);
        switch (errorCode){
          case 'auth/weak-password' :
            console.log("Network connection error");
            alert("Network connection error");
            break;
          case 'auth/invalid-email':
            console.log("Invalid email");
            alert("Invalid email");
            break;
          case 'auth/network-request-failed':
            console.log("Network connection error");
            alert("Network connection error");
            break;
          default:
            console.log("Error occured");
            alert("Error occured");
            break;
        }
      }
      );
      this.setState({
        authenticating : false
      });
      //alert('yeah');
    }else{
      this.setState({
        authenticating : false
      });
      alert("Password doesn't match");
    }
  }
  
  signUpButton() {
    if (this.state.authenticating){
      return (
        <TouchableOpacity style={styles.buttonContainer} disabled={true}>
          <ActivityIndicator size='small' style={{height: 25}} />
          </TouchableOpacity>
      );
    }else{
      return(
        <TouchableOpacity style={styles.buttonContainer} onPress={() => this.onPressSignUp()}>
          <Text style={styles.buttonText}>Register</Text>
          </TouchableOpacity>
      );
    }
  }

  renderCurrentState(){
    return (
      <View style={styles.container}>
        <View style={styles.formContainter}>
          <TextInput 
            borderColor='rgba(220,220,220,1)'
            borderWidth={1}
            placeholder="Email"
            placeholderTextColor = 'rgba(128,128,128,1)'
            returnKeyType = "next"
            keyboardType="email-address"
            autoCapitalize= "none"
            autoCorrect={false}
            onChangeText= {email => this.setState({email})}
            value = {this.state.email}
            onSubmitEditing = {() => this.passwordInput.focus()}
            style = {styles.input}
          />
          <TextInput 
            borderColor='rgba(220,220,220,1)'
            borderWidth={1}
            placeholder="Password"
            placeholderTextColor = 'rgba(128,128,128,1)'
            placholderAlign = "center"
            returnKeyType = "next"
            secureTextEntry
            onChangeText={password => this.setState({ password })}
            value={this.state.password}
            onSubmitEditing = {() => this.passwordInput.focus()}  
            style = {styles.input}
          />
          <TextInput 
            borderColor='rgba(220,220,220,1)'
            borderWidth={1}
            placeholder="Re-type Password"
            placeholderTextColor = 'rgba(128,128,128,1)'
            placholderAlign = "center"
            returnKeyType = "go"
            secureTextEntry
            onChangeText={retypePassword => this.setState({ retypePassword })}
            value={this.state.retypePassword}
            style = {styles.input}
            ref= {(input) => this.passwordInput = input}  
          />
          {this.signUpButton()}
        </View>
        <View style={styles.descContainer}>
          <Text style={styles.descText}>Already have an account? <Text onPress={() => this.props.navigation.goBack()} style={{color:'black', textDecorationLine:'underline'}} >Sign In.</Text></Text>
        </View>
      </View> 
    )
  }

  /**
   * When the App component mounts, we listen for any authentication
   * state changes in Firebase.
   * Once subscribed, the 'user' parameter will either be null 
   * (logged out) or an Object (logged in)
   */
  componentDidMount() {
    this.authRegister = firebase.auth().onAuthStateChanged((user) => {
      this.setState({
        authenticating: false,
        user
      });
      firebase.auth().signOut();
      user ? this.props.navigation.goBack(): null;
    });
  }
  
  /**
   * Don't forget to stop listening for authentication state changes
   * when the component unmounts.
   */
  componentWillUnmount() {
    this.authRegister();
  }

  render(){
    return (
      this.renderCurrentState()
    )
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  formContainter:{
    flexGrow:1,
    padding: 20,
    justifyContent: 'center',
    
    /*
    borderRadius: 4,
    borderWidth: 3,
    borderColor: '#abf122',*/
  },
  input: {
    height: 40,
    
    backgroundColor: 'rgba(245,245,245,1)',
    marginBottom: 10,
    color: '#FFF',
    paddingHorizontal : 10
  },
  loading: {
    height: 175
  },
  descContainer:{
    height : 40,
    paddingVertical : 10,
    borderTopColor: 'rgba(220,220,220,1)',
    borderTopWidth: 2,
    marginTop :10,
  },
  descText:{
    color:'gray',
    fontWeight: '400',
    textAlign: 'center',
    fontSize: 12,
  },
  buttonContainer: {
    borderColor:'rgba(220,220,220,1)',
    borderWidth: 1,
  	paddingVertical: 10
  },
  buttonText:{
  	textAlign : 'center',
    height: 20,
  	fontWeight: '700'
  }
});
